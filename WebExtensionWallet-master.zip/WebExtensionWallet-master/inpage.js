

var webExtensionWallet = "for nebulas";

console.log("webExtensionWallet is defined:" + webExtensionWallet);




